# Paige's Pizzaria 🍕

Welcome to the official website for Paige's Pizzaria — a handcrafted pizza experience with heart, flavor, and a hometown touch.

## 🍽 About

Paige’s Pizzaria serves up hand-tossed pizzas, fresh ingredients, and a friendly neighborhood vibe. Whether you're craving a Meat Lovers, Veggie Supreme, or the House Special — we’ve got something for everyone.

## 📁 Project Structure

```
/
├── index.html                # Main website file
├── images/                   # All pizza and team member images
│   ├── chicken-bacon-ranch.jpg
│   ├── bbq-chicken.jpg
│   ├── meat-lovers.jpg
│   ├── margherita.jpg
│   ├── house-special.jpg
│   ├── mediterranean.jpg
│   ├── veggie.jpg
│   ├── supreme.jpg
│   ├── italian.jpg
│   └── team member images
```

## 🚀 How to View the Site

Once uploaded to GitHub Pages:

**Live URL:**  
```
https://yourusername.github.io/paiges-pizzaria/
```

> Replace `yourusername` with your actual GitHub username.

## 💻 Built With

- HTML5
- CSS3
- Google Fonts
- Handcrafted pizza goodness

## 📬 Contact

**Phone:** 269.339.3774  
**Email:** info@paigespizzaria.com
